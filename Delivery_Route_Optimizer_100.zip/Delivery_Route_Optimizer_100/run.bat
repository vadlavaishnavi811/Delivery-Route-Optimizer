@echo off
title Delivery Route Optimizer
cd /d "%~dp0"

echo ==========================================
echo   DELIVERY ROUTE OPTIMIZER
echo ==========================================
echo.
echo Installing/checking Streamlit...
python -m pip install streamlit
echo.
echo Starting website...
python -m streamlit run app.py
pause
