# 🚚 Delivery Route Optimizer — Complete Project

This is a complete Streamlit web project for the problem:

> Design a delivery planner for a fleet visiting multiple customer locations.
> Minimize total distance or cost while producing an understandable visit sequence.

## Technologies

- Python
- Streamlit
- SQLite
- TSP
- Dynamic Programming
- Branch and Bound

## Project Structure

```text
Delivery_Route_Optimizer_100/
│
├── app.py
├── requirements.txt
├── run.bat
├── README.md
└── .gitignore
```

The SQLite database `delivery_routes.db` is created automatically after the first optimization.

## What the website supports

### 1. Fleet
Choose 1–4 vehicles.

### 2. Customer locations
Add as many customer rows as practical for the selected algorithm.

### 3. Minimum distance
The application assigns customers across the fleet and minimizes total route distance.

### 4. Minimum cost
The application uses:

```text
Total Cost = Distance × Cost Per Unit
           + Fixed Cost × Vehicles Used
```

### 5. TSP
Each vehicle gets an exact TSP tour:

```text
Warehouse → Customers → Warehouse
```

### 6. Dynamic Programming
Uses the Held-Karp dynamic-programming TSP approach.

Time: O(n² × 2ⁿ)
Space: O(n × 2ⁿ)

### 7. Branch and Bound
Builds routes recursively and prunes branches whose lower bound cannot improve the best known route.

Worst case: O(n!)

### 8. SQLite
Every optimized fleet plan is saved in:

```text
delivery_routes.db
```

The website displays the last 10 saved plans.

## Run

### Method A — Recommended

Open PowerShell in this folder and run:

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

### Method B — Double click

Double-click:

```text
run.bat
```

The batch file installs Streamlit if necessary and starts the website.

## Example

Use:

```text
Warehouse  (0,0)
Customer A (2,4)
Customer B (6,2)
Customer C (8,7)
Customer D (4,8)
```

Choose:

```text
Fleet Size: 2
Algorithm: Dynamic Programming
Objective: Minimum Distance
```

Then click:

```text
Optimize Fleet Routes
```

The application will produce routes such as:

```text
Vehicle 1
Warehouse → Customer A → Customer B → Warehouse

Vehicle 2
Warehouse → Customer C → Customer D → Warehouse
```

The exact result is calculated by the program.

## Important project note

The coordinates are a simplified grid representation so the algorithm can be demonstrated without requiring an external map API. In a real delivery system, these coordinates could be replaced by GPS/map distances.

## Hackathon explanation

The project solves a fleet-routing version of TSP. First, customers are assigned among the available vehicles. For each vehicle, an exact TSP solver finds the best tour. Dynamic Programming uses memoized subset states, while Branch and Bound uses a lower-bound function to prune routes that cannot improve the current solution. The best fleet plan is selected according to either total distance or total cost, and the result is saved in SQLite.
